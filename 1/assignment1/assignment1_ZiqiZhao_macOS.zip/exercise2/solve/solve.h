#include <vector>
#include <cmath>

using namespace std;

vector<double> solve(double a, double b, double c);